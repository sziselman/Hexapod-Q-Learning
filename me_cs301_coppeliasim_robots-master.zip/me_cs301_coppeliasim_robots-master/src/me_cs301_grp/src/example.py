#!/usr/bin/env python
### ^ mark python ros node as executable
import rospy
from sensor_msgs.msg import JointState
from std_msgs.msg import Float32

def main():
    pass

if __name__ == "__main__":
    main()